#operaciones matematicas

numero1=int(input("ingresa el primer numero: "))
numero2=int(input("ingresa el segundo numero: "))

suma=numero1+numero2
resta=numero1-numero2
multi=numero1*numero2
divi=numero1/numero2
print("la suma es: ",suma," \nlaresta es: ",resta," \nla multiplicacion es: ",multi, "\nla division es: ",divi)