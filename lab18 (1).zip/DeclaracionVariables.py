#definir y capturar valores por teclado

nombre=input("digite el nombre: ")#string 
edad=int(input("digite la edad: "))#numeroentero
estatura=float(input("digite su estatura: "))

estado=input("¿ESTUDIAS?: ");
#imprimir variables
print("Hola",nombre, " tienes ",edad," años de edad "," tu altura es de",estatura," mts "," estudias ", estado)








