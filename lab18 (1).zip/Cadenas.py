#Manipulacion de cadenas

frase1=input("Ingrese la frase 1: ")
frase2=input("Ingrese la frase 2: ")

mensaje=frase1+" "+frase2
#print(mensaje)
print(mensaje)
#f-string
print(f"{frase1}{frase2}")
