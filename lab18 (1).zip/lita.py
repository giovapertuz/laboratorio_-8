#lista vacia
my_list=[]
dato=input("ingrese datos: ")
my_list.append(dato)
dato1=input("ingrese dato:")
my_list.append(dato1)
print(my_list)