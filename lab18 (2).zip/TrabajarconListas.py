#creacion de listas

list=[5,"perro",5.22,False,"Piña"]
list[1]="Gato" #"modifico perro por Gato
list.append("Valledupar")#agregar un nuevo item a la lista
list.remove(5.22)#eliminar  elemento  de la lista de entero o numeros
list.remove(list[4])

print(list)