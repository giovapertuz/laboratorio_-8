#Diccionario

dicci={
    "Nombre":"Giovanny Alexander",
    "Edad":22,
    "Ciudad":"Valledupar",
    "Profesion":"Ingeniero de Sistemas"
}
print(dicci)
#modificar valores
dicci["Edad"]=32
print(dicci)
#Agregar valores en un Diccionario
dicci["Estatura"]=1.80
print(dicci)